package Clases;

import CRUD.DAOpropiedad;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import Formularios.InterfazGrafica;
import Clases.Implementacion_Usuario;

public class Implementacion_Propiedad extends BaseDeDatos implements DAOpropiedad {

    private String hash;
    private String cadena_bloques;
    private String id_usuario;
    private String claveHashBloqueAnterior;

    @Override
    public void registrar(Propiedad user) throws Exception {
        try {
            this.Conectar();

            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO propiedad(direccion, tamaño, precio, Dueño, descripcion, id_usuario) VALUES (?, ?, ?, ?, ?, ?)");
            st.setString(1, user.getDireccion());
            st.setInt(2, user.getTamaño());
            st.setDouble(3, user.getPrecio());
            st.setString(4, user.getDueño());
            st.setString(5, user.getDescripcion());
            st.setInt(6, getIdUsuario()); // Comprueba que exista un usuario con el id ingresado
            st.executeUpdate();
            this.conexion.setAutoCommit(false);
            this.conexion.commit(); // Aquí se hace commit de la transacción

            // Obtener el ID de la propiedad recién registrada desde la base de datos
            int propiedadId = obtenerUltimoIdPropiedad();

            // Generar hash y cadena de bloques
            generarHashYCadenaBloques(user, propiedadId);

            // Actualizar la clave hash del bloque anterior en el registro anterior (si existe)
            actualizarClaveHashBloqueAnterior(propiedadId);

            // Registrar en la base de datos de blockchain
            registrarEnBaseDeDatos(propiedadId);

        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    public int getIdUsuario() {
        return Integer.parseInt(InterfazGrafica.txt8.getText());
    }

    private int obtenerUltimoIdPropiedad() throws SQLException {
        int idPropiedad = 0;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT MAX(id) FROM propiedad");
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                idPropiedad = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.Cerrar();
        }
        return idPropiedad;
    }

    private void generarHashYCadenaBloques(Propiedad user, int propiedadId) throws SQLException {
        String dataToHash = propiedadId + getUsuarioId() + user.getDireccion() + user.getPrecio();
        hash = generarHash(dataToHash);
        claveHashBloqueAnterior = obtenerClaveHashBloqueAnterior(); // Obtener la clave hash del bloque anterior
        cadena_bloques = generarCadenaBloques(user, propiedadId);

        // Asignar el valor del ID de usuario
        id_usuario = Integer.toString(getIdUsuario());
    }

    private void actualizarClaveHashBloqueAnterior(int propiedadId) throws SQLException {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE blockchain SET clave_hash_bloque_anterior = ? WHERE propiedad_id = ?");
            st.setString(1, hash); // El nuevo hash generado
            st.setInt(2, propiedadId - 1); // El ID de la propiedad anterior

            st.executeUpdate();
            this.conexion.setAutoCommit(false);
            this.conexion.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.Cerrar();
        }
    }

    private String obtenerClaveHashBloqueAnterior() throws SQLException {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT hash FROM blockchain ORDER BY propiedad_id DESC LIMIT 1");
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return rs.getString("hash");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.Cerrar();
        }
        return null;
    }

    private String getUsuarioId() {
        return InterfazGrafica.txt8.getText();
    }

    private String generarHash(String dataToHash) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(dataToHash.getBytes());

            // Convertir el hash byte[] a una representación hexadecimal
            StringBuilder stringBuilder = new StringBuilder();
            for (byte hashByte : hashBytes) {
                stringBuilder.append(Integer.toString((hashByte & 0xff) + 0x100, 16).substring(1));
            }
            return stringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String generarCadenaBloques(Propiedad user, int propiedadId) throws SQLException {
        // Aquí puedes implementar la lógica para generar la cadena de bloques para la propiedad
        // Puedes obtener los datos necesarios de user y otras fuentes si es necesario
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("Propiedad: ").append(propiedadId).append("\n");
        stringBuilder.append("Usuario ID: ").append(getUsuarioId()).append("\n");
        stringBuilder.append("Hash bloque anterior: ").append(claveHashBloqueAnterior).append("\n");
        stringBuilder.append("Dirección: ").append(user.getDireccion()).append("\n");
        stringBuilder.append("Precio: ").append(user.getPrecio()).append("\n");
        //stringBuilder.append("NextHash: ").append(claveHashBloqueAnterior).append("\n");
        return stringBuilder.toString();
    }

    private String obtenerNextHash() throws SQLException {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT clave_hash_bloque_anterior FROM blockchain ORDER BY propiedad_id DESC LIMIT 1");
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return rs.getString("clave_hash_bloque_anterior");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.Cerrar();
        }
        return null;
    }

    private void registrarEnBaseDeDatos(int propiedadId) throws SQLException {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO blockchain(propiedad_id, hash, cadena_bloques, id_usuario) VALUES (?, ?, ?, ?)");
            st.setInt(1, propiedadId);
            st.setString(2, hash);
            st.setString(3, cadena_bloques);
            st.setString(4, id_usuario);
            st.executeUpdate();
            this.conexion.setAutoCommit(false);
            this.conexion.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Propiedad user) throws Exception {
        // ...
    }

    @Override
    public void eliminar(int propiedadId) throws Exception {
        // ...
    }

    @Override
    public List<Propiedad> listar() throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Propiedad ListarPropiedadId(int propiedadId) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
