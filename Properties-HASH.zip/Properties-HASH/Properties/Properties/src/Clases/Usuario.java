 package Clases;

/**
 * @author Carlos_Nimacache
 */
public class Usuario {
    private int id;
    private String nombre;
    private String email;

    public void setId(int id) {
        this.id = id;
    }
    
     public int getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}
