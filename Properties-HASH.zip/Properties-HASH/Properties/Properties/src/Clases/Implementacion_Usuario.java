package Clases;

import CRUD.DAOusuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


public class Implementacion_Usuario extends BaseDeDatos implements DAOusuario{

    public Implementacion_Usuario() throws ClassNotFoundException {
    super();
    this.Conectar();
}

    
    
    @Override
    public void registrar(Usuario user) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO usuarios(nombre, email)VALUES(?,?)");
            st.setString(1, user.getNombre());
            st.setString(2, user.getEmail());
            st.executeUpdate();
            
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        
    }

    @Override
    public void modificar(Usuario user) throws Exception {
    try {
        this.Conectar();
        PreparedStatement st = this.conexion.prepareStatement("UPDATE usuarios SET nombre = ?, email = ? WHERE id = ?");
        st.setString(1, user.getNombre());
        st.setString(2, user.getEmail());
        st.setInt(3, user.getId());

        st.executeUpdate();
        st.close();
    } catch(Exception e) {
        throw e;
    } finally {
        this.Cerrar();
    }
    }

    @Override
    public void eliminar(int userId ) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM usuarios WHERE Id = ?;");
            st.setInt(1, userId);
            st.executeUpdate();
            
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }

    }

    @Override
    public List<Usuario> listar() throws Exception {
        List<Usuario> lista = null;
        try{
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM usuarios;");
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            
            while(rs.next()){
                Usuario user = new Usuario();
                
                user.setId(rs.getInt("id"));
                user.setNombre(rs.getString("nombre"));
                user.setEmail(rs.getString("email"));
                lista.add(user);
                
            }
            
            rs.close();
            st.close();
            
        } catch (Exception e){
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Usuario ListarUsuarioId(int userId) throws Exception {
       Usuario user = new Usuario();
        
       try{
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM usuarios WHERE Id = ? Limit 1;");
            
            st.setInt(1, userId);
            
            ResultSet rs = st.executeQuery();
            
            while(rs.next()){
                
                user.setId(rs.getInt("id"));
                user.setNombre(rs.getString("nombre"));
                user.setEmail(rs.getString("email"));
                
            }
            
            rs.close();
            st.close();
            
        } catch (Exception e){
            throw e;
        } finally {
            this.Cerrar();
        }
        return user;
        
        
    }
    
    
public String obtenerNombreUsuarioPorId(int id) {
    
    String nombre = "";
    try {
        String query = "SELECT nombre FROM usuarios WHERE id = ?";
        PreparedStatement preparedStatement = this.conexion.prepareStatement(query);
        preparedStatement.setInt(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            nombre = resultSet.getString("nombre");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Mostrar un mensaje de depuración para verificar si se ha obtenido el nombre del usuario correctamente
    System.out.println("Nombre del usuario con ID " + id + ": " + nombre);

    return nombre;
    }
}
