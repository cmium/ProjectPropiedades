package Clases;

import org.bouncycastle.jcajce.provider.digest.SHA256;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Blockchain {

    private BaseDeDatos baseDeDatos;
    private List<Block> chain;

    public Blockchain(BaseDeDatos baseDeDatos) {
        this.baseDeDatos = baseDeDatos;
        chain = new ArrayList<>();
        chain.add(createGenesisBlock());
    }

    public Blockchain() {
        chain = new ArrayList<>();
        chain.add(createGenesisBlock());
    }

    private Block createGenesisBlock() {
        return new Block(0, "0", "Genesis Block");
    }

    public void addBlock(String data) {
        Block previousBlock = chain.get(chain.size() - 1);
        Block newBlock = new Block(previousBlock.getIndex() + 1, previousBlock.getHash(), data);
        chain.add(newBlock);
    }

    public void removeBlock(int userId) {
        Iterator<Block> iterator = chain.iterator();
        while (iterator.hasNext()) {
            Block block = iterator.next();
            if (block.getData().contains("User ID: " + userId)) {
                iterator.remove();
                break;
            }
        }
    }

    public String hash(String input) {
        MessageDigest digest = new SHA256.Digest();
        byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public Block getLatestBlock() {
        return chain.get(chain.size() - 1);
    }

    public class Block {
        private int index;
        private String previousHash;
        private String data;
        private String hash;

        public Block(int index, String previousHash, String data) {
            this.index = index;
            this.previousHash = previousHash;
            this.data = data;
            this.hash = Blockchain.this.hash(index + previousHash + data);
        }

        public int getIndex() {
            return index;
        }

        public String getPreviousHash() {
            return previousHash;
        }

        public String getData() {
            return data;
        }

        public String getHash() {
            return hash;
        }
    }
}
