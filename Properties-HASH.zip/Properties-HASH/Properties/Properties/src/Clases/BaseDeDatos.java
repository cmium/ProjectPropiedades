package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Carlos_Nimacache
 */
public class BaseDeDatos {

    protected Connection conexion;
    private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String DB_URL = "jdbc:mysql://localhost:3306/propiedades";
    private final String USER = "root";
    private final String PASS = "K@li2023";

    public void Conectar() throws ClassNotFoundException {
        try {
            Class.forName(JDBC_DRIVER);
            conexion = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (SQLException ex) {
            Logger.getLogger(BaseDeDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Cerrar() throws SQLException {
        if (conexion != null) {
            if (!conexion.isClosed()) {
                conexion.close();
            }
        }
    }

    public int obtenerIdUsuario(String nombreUsuario) throws SQLException {
        int idUsuario = -1;
        String sql = "SELECT id_usuario FROM usuarios WHERE nombre_usuario = ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, nombreUsuario);
        ResultSet result = statement.executeQuery();
        if (result.next()) {
            idUsuario = result.getInt("id_usuario");
        }
        return idUsuario;
    }
}
