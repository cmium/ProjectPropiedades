package Clases;

public class Propiedad {
    
    private final int id;
    private String direccion;
    private int tamaño;
    private double precio;
    private String descripcion;
    private String dueño;
    
    public Propiedad(int id, String direccion, int tamaño, double precio, String descripcion, String dueño) {
        this.id = id;
        this.direccion = direccion;
        this.tamaño = tamaño;
        this.precio = precio;
        this.descripcion = descripcion;
        this.dueño = dueño;
    }

    // Constructor vacío
    public Propiedad() {
        this.id = 0; // Asigna un valor predeterminado al atributo 'id'
    }

    public int getId() {
        return id;
    }
    
    public String getDireccion() {
        return direccion;
    }
    
    public int getTamaño() {
        return tamaño;
    }
    
    public double getPrecio() {
        return precio;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public String getDueño() {
        return dueño;
    }
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }
    
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public void setDueño(String dueño) {
        this.dueño = dueño;
    }

    int getIdUsuario() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
