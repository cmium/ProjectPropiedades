package Clases;

import CRUD.DAOpropiedad;
import Formularios.InterfazGrafica;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Implementacion_Propiedad extends BaseDeDatos implements DAOpropiedad {

    private static final int HASH_LENGTH = 15;

 @Override
public void registrar(Propiedad propiedad) throws Exception {
    try {
        this.Conectar();
        
        // Establecer autocommit en false
        this.conexion.setAutoCommit(false);

        // Insertar los datos de la propiedad en la tabla "propiedad"
        PreparedStatement st = this.conexion.prepareStatement("INSERT INTO propiedad(direccion, tamaño, precio, Dueño, descripcion, id_usuario) VALUES (?, ?, ?, ?, ?, ?)");
        st.setString(1, propiedad.getDireccion());
        st.setInt(2, propiedad.getTamaño());
        st.setDouble(3, propiedad.getPrecio());
        st.setString(4, propiedad.getDueño());
        st.setString(5, propiedad.getDescripcion());
        st.setInt(6, getIdUsuario());
        st.executeUpdate();

        // Generar la clave hash y construir la cadena de bloques
        int propiedadId = obtenerUltimoIdPropiedad();
        String hash = generarHash(propiedadId, propiedad.getDireccion(), propiedad.getPrecio());
        String cadenaBloques = construirCadenaBloques(propiedadId, hash);

        // Insertar los datos de la cadena de bloques en la tabla "blockchain"
        st = this.conexion.prepareStatement("INSERT INTO blockchain(propiedad_id, hash, cadena_bloques) VALUES (?, ?, ?)");
        st.setInt(1, propiedadId);
        st.setString(2, hash);
        st.setString(3, cadenaBloques);
        st.executeUpdate();

        // Realizar commit explícito
        this.conexion.commit();
    } catch (Exception e) {
        // Realizar rollback en caso de excepción
        this.conexion.rollback();
        throw e;
    } finally {
        // Restaurar autocommit a true y cerrar la conexión
        this.conexion.setAutoCommit(true);
        this.Cerrar();
    }
}


    private int getIdUsuario() throws SQLException {
        // Obtener el ID de usuario desde la interfaz gráfica o cualquier otro método que utilices
        return Integer.parseInt(InterfazGrafica.txt8.getText());
    }

    private int obtenerUltimoIdPropiedad() throws SQLException {
        int ultimoId = -1;
        String sql = "SELECT MAX(id) AS ultimoId FROM propiedad";
        PreparedStatement statement = conexion.prepareStatement(sql);
        ResultSet result = statement.executeQuery();
        if (result.next()) {
            ultimoId = result.getInt("ultimoId");
        }
        return ultimoId;
    }

    private String generarHash(int propiedadId, String direccion, double precio) throws NoSuchAlgorithmException {
        String data = propiedadId + direccion + precio;

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = md.digest(data.getBytes());

        StringBuilder sb = new StringBuilder();
        for (byte b : hashBytes) {
            sb.append(String.format("%02x", b));
        }

        return sb.substring(0, HASH_LENGTH);
    }

    private String construirCadenaBloques(int propiedadId, String hash) throws SQLException {
        StringBuilder cadenaBloques = new StringBuilder();

        // Consultar todas las propiedades anteriores a la propiedad actual
        String sql = "SELECT id, hash FROM blockchain WHERE propiedad_id < ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, propiedadId);
        ResultSet result = statement.executeQuery();

        while (result.next()) {
            int id = result.getInt("id");
            String bloqueHash = result.getString("hash");

            cadenaBloques.append(id).append(":").append(bloqueHash).append("->");
        }

        // Agregar el bloque actual a la cadena de bloques
        cadenaBloques.append(propiedadId).append(":").append(hash);

        return cadenaBloques.toString();
    }

    // Resto de los métodos de la interfaz DAOpropiedad
    // ...

    @Override
    public void modificar(Propiedad user) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminar(int propiedadId) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Propiedad> listar() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Propiedad ListarPropiedadId(int propiedadId) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
