
package CRUD;

import Clases.Usuario;
import java.util.List;

/**
 * @author Carlos_Nimacache
 */

public interface DAOusuario {
    
  public void registrar (Usuario user) throws Exception;
  public void modificar (Usuario user) throws Exception;
  public void eliminar (int userId) throws Exception;
  public List<Usuario> listar () throws Exception;
  public Usuario ListarUsuarioId (int userId) throws Exception;

}
