
package CRUD;

import Clases.Propiedad;
import java.util.List;

/**
 * @author Carlos_Nimacache
 */
public interface DAOpropiedad {
    
  public void registrar (Propiedad user) throws Exception;
  public void modificar (Propiedad user) throws Exception;
  public void eliminar (int propiedadId) throws Exception;
  public List<Propiedad> listar () throws Exception;
  public Propiedad ListarPropiedadId (int propiedadId) throws Exception;
}
