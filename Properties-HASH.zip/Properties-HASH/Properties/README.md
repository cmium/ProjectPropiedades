# Properties
java GUI properties program
